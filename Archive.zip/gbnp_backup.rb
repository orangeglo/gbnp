require 'pry'

class Rom
  CARTRIDGE_TYPES = [
    'ROM Only',
    'MBC1', 'MBC1+RAM', 'MBC1+RAM+BATTERY', nil,
    'MBC2', 'MBC2+BATTERY', nil,
    'ROM+RAM', 'ROM+RAM+BATTERY', nil, nil, nil, nil, nil,
    'MBC3+TIMER+BATTERY', 'MBC3+TIMER+RAM+BATTERY', 'MBC3', 'MBC3+RAM', 'MBC3+RAM+BATTERY', nil, nil, nil, nil, nil,
    'MBC5', 'MBC5+RAM', 'MBC5+RAM+BATTERY', 'MBC5+RUMBLE', 'MBC5+RUMBLE+RAM', 'MBC5+RUMBLE+RAM+BATTERY'
  ].freeze

  attr_accessor :title, :cgb, :type_byte, :rom_byte, :ram_byte, :bytes

  def rom_size_kb
    32 << rom_byte
  end

  def padded_rom_size_kb
    padded? ? 128 : rom_size_kb
  end

  def ram_size_kb
    return 0.5 if type_byte == 0x06

    (4 ** (ram_byte - 1)).to_i * 2
  end

  def padded?
    rom_size_kb < 128
  end

  def type
    CARTRIDGE_TYPES[type_byte]
  end

  def ascii_title
    "#{cgb ? 'CGB' : 'DMG'} -A#{title[0..1]}J-  "
  end

  def to_s
    {
      title: title,
      ascii_title: ascii_title,
      type_byte: type_byte,
      type: type,
      cgb: cgb,
      rom_byte: rom_byte,
      rom_size_kb: rom_size_kb,
      ram_byte: ram_byte,
      ram_size_kb: ram_size_kb
    }.to_s
  end

  def self.build_from_file(file_path)
    new.tap do |rom|
      File.open(file_path, 'rb') do |file|
        file.seek(0x134)
        rom.title = file.read(0xF)

        file.seek(0x143)
        cgb_byte = file.readbyte
        rom.cgb = cgb_byte == 0x80 || cgb_byte == 0xC0

        file.seek(0x147)
        rom.type_byte = file.readbyte
        rom.rom_byte = file.readbyte
        rom.ram_byte = file.readbyte

        file.rewind
        rom.bytes = ByteArray.new(rom.padded_rom_size_kb * 1024)
        file.each_byte { |byte| rom.bytes.write_byte(byte) }

        raise RAMOverflowError unless rom.ram_size_kb <= 32
        raise UnknownTypeError unless rom.type
      end
    end
  end

  class RAMOverflowError < StandardError
    def message; 'ROMs with more than 32KB of ram are not supported'; end
  end
  class UnknownTypeError < StandardError
    def message; 'ROM cartridge type is unknown'; end
  end
end

class Map
  FINAL_BYTES = [0x02, 0x00, 0x30, 0x12, 0x99, 0x11, 0x12, 0x20, 0x37, 0x57, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00].freeze

  def initialize(roms)
    @roms = roms
    @byte_array = build_byte_array
  end

  attr_reader :roms, :byte_array

  def write(file_path)
    byte_array.write_out(file_path)
  end

  private

  def build_byte_array
    ByteArray.new.tap do |byte_array|
      # write mbc type, rom size, and ram size for menu
      byte_array.write_bytes(0xA8, 0, 0)

      rom_offset = 128
      ram_offset = 0

      # write mbc type, rom size, and ram size for each rom
      roms.each do |rom|
        bits = Array.new(16, 0)
        set_mbc_bits(bits, rom)
        set_rom_bits(bits, rom)
        set_ram_bits(bits, rom)
        byte_array.write_bytes(*rom_offset_and_cart_info_bytes(bits, rom, rom_offset))
        byte_array.write_byte(ram_offset / 2)

        rom_offset += rom.padded? ? 128 : rom.rom_size_kb
        ram_offset += (rom.type_byte == 0x06 || rom.ram_size_kb < 8) ? 8 : rom.ram_size_kb
      end

      byte_array.write_bytes(*([0xFF] * (0x6E - byte_array.data.length)))
      byte_array.write_bytes(*FINAL_BYTES)
    end
  end

  def set_mbc_bits(bits, rom)
    case(rom.type_byte)
    when 0x01..0x03 # MBC1 001
      bits[15] = 0; bits[14] = 0; bits[13] = 1
    when 0x05..0x06 # MBC2 010
      bits[15] = 0; bits[14] = 1; bits[13] = 0
    when 0x0F..0x13 # MBC3 011
      bits[15] = 0; bits[14] = 1; bits[13] = 1
    when 0x19..0x1E # MBC5 100
      bits[15] = 1; bits[14] = 0; bits[13] = 0
    end
  end

  def set_rom_bits(bits, rom)
    case(rom.rom_size_kb)
    when 64 # 010
      bits[12] = 0; bits[11] = 1; bits[10] = 0
    when 128 # 010
      bits[12] = 0; bits[11] = 1; bits[10] = 0
    when 256 # 011
      bits[12] = 0; bits[11] = 1; bits[10] = 1
    when 512 # 100
      bits[12] = 1; bits[11] = 0; bits[10] = 0
    when 1024 # 101
      bits[12] = 1; bits[11] = 0; bits[10] = 1;
    end
  end

  def set_ram_bits(bits, rom)
    if rom.type_byte == 0x06 # MBC2+BATTERY 001
      bits[9] = 0; bits[8] = 0; bits[7] = 1
    elsif(rom.ram_size_kb == 0) # No RAM 000
      bits[9] = 0; bits[8] = 0; bits[7] = 0
    elsif(rom.ram_size_kb == 8) # 8KB 010
      bits[9] = 0; bits[8] = 1; bits[7] = 0
    elsif(rom.ram_size_kb >= 32) # 32KB+ 011
      bits[9] = 0; bits[8] = 1; bits[7] = 1
    else # < 8KB 010
      bits[9] = 0; bits[8] = 1; bits[7] = 0
    end
  end

  def rom_offset_and_cart_info_bytes(bits, rom, rom_offset)
    bits.reverse!
    [bits[0..7].join.to_i(2), bits[8..15].join.to_i(2)].tap do |bytes|
      bytes[1] = bytes[1] | rom_offset / 32
    end
  end
end

class ByteArray
  def initialize(size = 0, fill = 0)
    @size = size
    @fill = fill
    @position = 0
    @data = Array.new(size, fill)
  end

  attr_reader :size, :fill, :position, :data

  def seek(position)
    @position = position
  end

  def forward(bytes)
    @position += bytes
  end

  def reverse(bytes)
    @position -= bytes
  end

  def write_byte(byte)
    write_bytes(byte)
  end

  def write_bytes(*bytes)
    bytes.each do |byte|
      @data[@position] = byte
      @position += 1
    end
  end

  def write_out(file_path)
    File.open(file_path, 'wb') do |f|
      f.write(data.pack('C*'))
    end
  end
end

class Menu
  def initialize(roms, menu_file_path)
    @roms = roms
    @byte_array = build_byte_array(menu_file_path)
  end

  attr_reader :roms, :byte_array

  def write(file_path)
    byte_array.write_out(file_path)
  end

  private

  def build_byte_array(menu_file_path)
    ByteArray.new(1024 ** 2).tap do |byte_array|
      File.open(menu_file_path, 'rb') do |f|
        f.each_byte { |byte| byte_array.write_byte(byte) }
      end

      rom_base = 0x01
      byte_array_base = 0x1C200
      roms.each_with_index do |rom, i|
        byte_array.seek(byte_array_base)

        # rom index
        byte_array.write_byte(i + 1)

        # rom base (in 128k units)
        # byte_array.write_byte((128 + rom.padded_rom_size_kb * i / 128) / 128) # this seems like it could be better
        byte_array.write_byte(rom_base)
        rom_base += rom.padded_rom_size_kb / 128

        # sram base?
        byte_array.write_byte(0)

        # rom size in (in 128k units)
        byte_array.write_byte((rom.padded? ? 128 : rom.rom_size_kb) / 128)
        byte_array.write_byte(0)

        # sram size in 32-byte units (this is hardcoded to zero in the source?)
        byte_array.write_byte(0)
        byte_array.write_byte(0)

        # # title ascii
        # byte_array.write_bytes(*rom.ascii_title.unpack('C*'))

        # # title shift-jis
        # byte_array.write_bytes(*"これを読めば、あなたはばかだ".ljust(32).encode(Encoding::Shift_JIS).unpack('C*'))

        # # ??? fix alignment
        # byte_array.reverse(2)

        # byte_array.forward(1)
        # puts byte_array.position

        byte_array.seek(byte_array_base + 63)

        # # title bitmap
        byte_array.write_bytes(*([0xFF] * 192))

        # # skip timestamp and LAW
        # byte_array.forward(192)

        # # write FF (already written but whatever)
        # byte_array.write_bytes(*([0xFF] * 39))
        byte_array_base += 512
      end

      # write roms
      byte_array.seek(0x20000)
      roms.each_with_index do |rom, i|
        byte_array.write_bytes(*rom.bytes.data)
      end
    end
  end
end

class GameBoyNintendoPower
  def self.run
    rom = Rom.build_from_file('rom.gb')
    puts rom

    rom2 = Rom.build_from_file('marioland.gb')
    puts rom2

    rom3 = Rom.build_from_file('drmario.gb')
    puts rom3

    map = Map.new([rom2, rom, rom3])
    map.write('output3.map')

    menu = Menu.new([rom2, rom, rom3], 'menu.gb')
    menu.write('output3.gb')
  end
end

GameBoyNintendoPower.run
